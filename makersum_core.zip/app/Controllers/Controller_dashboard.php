<?php namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\PostModel;

use PDO;

class Controller_dashboard extends BaseController{

    public function index(){
        $data['name'] = "Dashboard";        

        echo view("dashboard_view", $data);
    }

    public function countDashboard(){        
        $data['name'] = "Dashboard";
        
        $db = new PDO('mysql:host=localhost;dbname=DBmakersum', 'root', '');

        // Query the database to get the total number of records
        $stmt = $db->query('SELECT COUNT(*) FROM posts');
        $row = $stmt->fetch(PDO::FETCH_NUM);

        // Return the result as a JSON response
        header('Content-Type: application/json');
        echo json_encode(['total' => $row[0]]);

        echo view("dashboard_view", $data);
    }



    public function fetch_main() {
        $postModel = new PostModel();
        $posts = $postModel->findAll();        
        $data = '';

        if ($posts) {
            foreach ($posts as $post) {                                    
                $data .= '
                <div class="col-md-4 mb-4">               
                    <div class="card overflow-hidden shadow"> <img class="card-img-top" src="uploads/avatar/' . $post['image'].'"/ height="350" >
                        <div class="card-body py-4 px-3">
                            <div class="d-flex flex-column flex-lg-row justify-content-between mb-3">
                            <h4 class="text-secondary fw-medium"><a class="link-900 text-decoration-none stretched-link" href="#!">' . $post['title_product'] . '</a></h4>
                            </div>
                            <div class="d-flex align-items-center"><span class="fs-0 fw-medium">By Admin</span></div>
                        </div>
                        </div>              
                    </div>';
            //   print_r(json_encode((object)$data));
            }
            return $this->response->setJSON([
                'error' => false,
                'message' => $data
            ]);
        } else {
            return $this->response->setJSON([
                'error' => false,
                'message' => '<div class="text-secondary text-center fw-bold my-5">No posts found in the database!</div>'
            ]);
        }
    }
}